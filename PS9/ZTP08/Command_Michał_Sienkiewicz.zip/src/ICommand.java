interface ICommand {
    void execute();
    void undo();
}
