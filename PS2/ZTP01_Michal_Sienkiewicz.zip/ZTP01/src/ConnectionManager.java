interface ConnectionManager {
    DatabaseConnection getConnection(String databaseName);
}