interface IMessage {
    int getId();
    void setId(int id);
    String getTitle();
    void setTitle(String title);
    String getContent();
    void setContent(String content);
}