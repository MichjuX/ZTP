enum UserRole {
    GUEST,
    USER,
    MODERATOR,
    ADMIN
}
